import axios from 'axios';

const API_URL = 'http://localhost:4000';

export const login = async (email: string, password: string) => {
  try {
    const response = await axios.post(`${API_URL}/auth/login`, { email, password });
    return response.data;  // Retorna a resposta completa
  } catch (error) {
    console.error('Error during login request:', error);
    throw error;
  }
};


export const logout = async () => {
  const token = localStorage.getItem('token');
  await axios.post(
    `${API_URL}/auth/logout`,
    {},
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
  localStorage.removeItem('token');
};

export const getStatistics = async (startDate: string, endDate: string) => {
  const token = localStorage.getItem('token');
  const response = await axios.get(`${API_URL}/statistics`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
    params: { startDate, endDate },
  });
  return response.data;
};
