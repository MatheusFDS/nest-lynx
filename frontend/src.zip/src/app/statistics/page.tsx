'use client';

import React, { useEffect, useState } from 'react';
import  withAuthorization  from '../hoc/withAuthorization';
import { getStatistics } from '../../services/api';
import {
  Container,
  Typography,
  CircularProgress,
  Box,
  Grid,
  Paper,
  TextField,
  Button,
} from '@mui/material';
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import dayjs from 'dayjs';

const StatisticsPage: React.FC = () => {
  const [statistics, setStatistics] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [startDate, setStartDate] = useState<string>(dayjs().startOf('year').format('YYYY-MM-DD'));
  const [endDate, setEndDate] = useState<string>(dayjs().endOf('year').format('YYYY-MM-DD'));

  const fetchStatistics = async () => {
    setLoading(true);
    try {
      const data = await getStatistics(startDate, endDate);
      setStatistics(data);
    } catch (error: any) {
      setError('Failed to fetch statistics');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStatistics();
  }, [startDate, endDate]);

  const handleDateChange = (field: 'start' | 'end', value: string) => {
    if (field === 'start') {
      setStartDate(value);
    } else {
      setEndDate(value);
    }
  };

  if (loading) {
    return (
      <Box
        sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}
      >
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Container>
        <Typography variant="h5" color="error" align="center">
          {error}
        </Typography>
      </Container>
    );
  }

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

  const renderPieChart = (data: any[], title: string) => (
    <ResponsiveContainer width="100%" height={300}>
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          labelLine={false}
          label={({ name, value }) => `${name}: ${value}`}
          outerRadius={80}
          fill="#8884d8"
          dataKey="value"
        >
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip />
      </PieChart>
    </ResponsiveContainer>
  );

  const ordersData = [
    { name: 'Pending', value: statistics?.ordersPending },
    { name: 'In Route', value: statistics?.ordersInRoute },
    { name: 'Finalized', value: statistics?.ordersFinalized },
  ];

  const freightsData = [
    { name: 'To Pay', value: statistics?.freightsToPay },
    { name: 'Paid', value: statistics?.freightsPaid },
  ];

  const deliveriesByDriverData = statistics?.deliveriesByDriver.map((item: any) => ({
    name: `Driver ${item.motoristaId}`,
    value: item._count.motoristaId,
  })) || [];

  const deliveriesData = [
    { name: 'In Route', value: statistics?.deliveriesInRoute },
    { name: 'Finalized', value: statistics?.deliveriesFinalized },
  ];

  const notesByRegionData = statistics?.notesByRegion.map((item: any) => ({
    name: item.cidade,
    value: item._count.cidade,
  })) || [];

  return (
    <Container>
      <Typography variant="h4" gutterBottom>
        Statistics
      </Typography>
      <Grid container spacing={3} alignItems="center">
        <Grid item xs={12} md={4}>
          <TextField
            label="Start Date"
            type="date"
            value={startDate}
            onChange={(e) => handleDateChange('start', e.target.value)}
            fullWidth
            InputLabelProps={{
              shrink: true,
            }}
          />
        </Grid>
        <Grid item xs={12} md={4}>
          <TextField
            label="End Date"
            type="date"
            value={endDate}
            onChange={(e) => handleDateChange('end', e.target.value)}
            fullWidth
            InputLabelProps={{
              shrink: true,
            }}
          />
        </Grid>
        <Grid item xs={12} md={4}>
          <Button variant="contained" color="primary" onClick={fetchStatistics}>
            Update
          </Button>
        </Grid>
      </Grid>
      <Grid container spacing={3} mt={3}>
        <Grid item xs={12} md={6}>
          <Paper elevation={3}>
            <Typography variant="h6" align="center" gutterBottom>
              Orders
            </Typography>
            {renderPieChart(ordersData, 'Orders')}
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper elevation={3}>
            <Typography variant="h6" align="center" gutterBottom>
              Freights
            </Typography>
            {renderPieChart(freightsData, 'Freights')}
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper elevation={3}>
            <Typography variant="h6" align="center" gutterBottom>
              Deliveries by Driver
            </Typography>
            {renderPieChart(deliveriesByDriverData, 'Deliveries by Driver')}
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper elevation={3}>
            <Typography variant="h6" align="center" gutterBottom>
              Deliveries
            </Typography>
            {renderPieChart(deliveriesData, 'Deliveries')}
          </Paper>
        </Grid>
        <Grid item xs={12} md={12}>
          <Paper elevation={3}>
            <Typography variant="h6" align="center" gutterBottom>
              Notes by Region
            </Typography>
            {renderPieChart(notesByRegionData, 'Notes by Region')}
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default withAuthorization(StatisticsPage);
