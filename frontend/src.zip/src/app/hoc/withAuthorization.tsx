// src/app/components/withAuthorization.tsx
import React from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '../context/AuthContext';

const withAuthorization = (WrappedComponent: React.ComponentType) => {
  const Wrapper: React.FC = (props) => {
    const { token } = useAuth();
    const router = useRouter();

    React.useEffect(() => {
      if (!token) {
        router.push('/login');
      }
    }, [token, router]);

    if (!token) {
      return null; // Ou um spinner de loading
    }

    return <WrappedComponent {...props} />;
  };

  return Wrapper;
};

export default withAuthorization;
