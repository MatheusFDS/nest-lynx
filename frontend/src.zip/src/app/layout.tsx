// src/app/layout.tsx
'use client';

import { Inter } from 'next/font/google';
import './globals.css';
import { AuthProvider, useAuth } from './context/AuthContext';
import Navbar from './components/Navbar'; // Ajuste o caminho conforme necessário

const inter = Inter({ subsets: ['latin'] });

const AppLayout = ({ children }: { children: React.ReactNode }) => {
  const { token } = useAuth();
  return (
    <>
      {token && <Navbar />}
      {children}
    </>
  );
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <AuthProvider>
          <AppLayout>
            {children}
          </AppLayout>
        </AuthProvider>
      </body>
    </html>
  );
}
