import { Typography, Button } from '@mui/material';
import Link from 'next/link';

export default function Home() {
  return (
    <>
      <Typography variant="h4" component="h1" gutterBottom>
        Sistema de Gestão de Entregas
      </Typography>
      <Link href="/login" passHref>
        <Button variant="contained" color="primary">
          Login
        </Button>
      </Link>
    </>
  );
}
