// src/tenant/dto/create-tenant.dto.ts
export class CreateTenantDto {
    readonly name: string;
    readonly email: string;
    readonly address: string;
  }
  