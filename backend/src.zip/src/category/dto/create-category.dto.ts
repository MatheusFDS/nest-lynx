export class CreateCategoryDto {
  name: string;
  valor: number;
  tenantId: string;  // Alterado para string
}
